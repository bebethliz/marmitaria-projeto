"""Ponto de entrada: `python wsgi.py` (local) ou `gunicorn wsgi:app` (produção)."""

import os

from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
